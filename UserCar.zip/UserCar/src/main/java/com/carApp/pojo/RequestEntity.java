package com.carApp.pojo;

import java.util.List;

public class RequestEntity {
	
	//private Object data;

}
